<script lang="ts">
    export let name: string = "";
    export let message: string = "";
</script>

<div class="card">
    <div class="card-body">
        {name}: {message}
    </div>
</div>